#!/bin/bash

sudo webalizer
